set prompt = "#\! "
# setenv EXINIT 'set number autowrite writeany'
alias l ls -l
