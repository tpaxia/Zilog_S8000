# .cshrc
#  Csh startup command file for zeus super user .....
#	features:
#	-	sets path to find most admin type commands (/etc esp.)
#	-	sets history list for easy command correction
#	-	sets mail
#	-	sets prompt to identify user as super and should be careful
#			not to destroy anything
#	-	sets up convenient, commonly used alias's
#

# Set path for csh and sh
set path=( . /bin /usr/bin /z/unify/bin /etc /z/rootbin )
setenv PATH ":/bin:/usr/bin:/z/unify/bin:/etc:/z/rootbin:"
setenv UNIFY "/z/unify/lib"
setenv DBROOT "/avs"
setenv DBPATH "/avs/bin"
setenv DAT "/avs/dat"
setenv DATETP "E"
setenv PIPE_PATH "/avs/pipe"
setenv XLIB "/avs/xlib"
setenv XDOC "/avs/xdoc"
setenv HEAD "/avs/dat/esel/head"
setenv SCR "/avs/scr"
setenv RIP "/avs/rip"
setenv SQL "/avs/sql"
setenv SRC "/avs/src"
setenv SEM "/avs/sem"
setenv SPOOL "/avs/spool"
setenv SPOOLER "/avs/adm/spooler"

# Set want shell variables
set prompt = "##\! "
set mail=/usr/spool/mail/zeus
set history = 18

setenv EXINIT 'set number autowrite writeany'

# Setup the aliases
alias gt 'set gt=`/bin/pwd`;cd \!^'
alias gb 'set gb=`/bin/pwd`;cd $gt;set gt=$gb'
alias h history
alias ll ls -la

