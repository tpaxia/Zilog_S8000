#
/****************************************************************************
*
*  This routine is part of UNIFY's COBOL interface.  It is supplied to allow
*  you to add other programs to the package.  For example, given this COBOL
*  statement:
*
*	CALL "PROG" USING ANAME.
*
*  the following code could be added to a copy of this routine, assuming
*  your program's name is "yoursub" (which may or may not require arguments):
*
*	if (scomp (argv[0], "PROG", 4) == 0)
*	{
*	    yoursub (argc, argv);
*	    return 0;
*	}
*
*  This routine returns 0 if a program is called (such as Usub), and -1 if
*  not.
*****************************************************************************/

sub (argc, argv)
int argc;
char *argv [];
{
    if (scomp (argv[0], "UNIFY", 5) == 0)
	return (Usub (argc, argv));

    return -1;       /* program not found */
}
