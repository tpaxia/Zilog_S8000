1,$ s/\_\\_/_/g
1,$ s/\_\/#DF0;#UL1;#DF1;/g
1,$ s/.../#DF0;#BO2;#DF1;/g
1,$ s/#DF0;#UL1;#DF1;./&#DF0;#UL0;#DF1;/g
1,$ s/#DF0;#BO2;#DF1;./&#DF0;#BO0;#DF1;/g
1,$ s/#DF0;#UL0;#DF1;#DF0;#UL1;#DF1;//g
1,$ s/#DF0;#BO0;#DF1;#DF0;#BO2;#DF1;//g
1,$ s/#DF0;#UL0;#DF1;\_#DF0;#UL1;#DF1;/ /g
1,$ s/#DF0;#BO0;#DF1;\.#DF0;#BO2;#DF1;/./g
1,$ s/.//g
