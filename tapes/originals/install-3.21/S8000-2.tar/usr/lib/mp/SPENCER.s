ID;PMP
F;DG0G10
F;W1 2 15
F;F$2D;C2
B;Y15;X2
C;Y3;X1;K"Sales"
C;X2;K20000
C;Y5;X1;K"Costs"
C;Y6;K"Material"
F;FD0R
C;X2;K4000
C;Y7;X1;K"Labor"
F;FD0R
C;X2;K7000
C;Y8;X1;K"Overhead"
F;FD0R
C;X2;K4000
C;Y9;K"  -----------------"
C;Y10;X1;K"Total Costs"
C;X2;ESUM(R[-4]C:R[-2]C);K15000
C;Y15;X1;K"Gross Profits"
C;X2;ESUM(R[-12]C-R[-5]C);K5000
W;N1;A1 1
E
