# /etc/.cshrc

#  Csh startup command file for zeus user .....
#	features:
#	-	sets path to find most admin type commands (/etc esp.)
#	-	sets history list for easy command correction
#	-	sets mail
#	-	sets prompt to identify user as super and should be careful
#			not to destroy anything
#	-	sets up convenient, commonly used alias's
#

# Set path for csh and sh
set path=(. /z/bin /bin /usr/bin /etc)
setenv PATH ":/z/bin:/bin:/usr/bin:/etc:"

# Set want shell variables
if ($?prompt) then
  if (("$prompt" == "% ") || ("$prompt" == "# ")) then
	set prompt = $prompt
	set prompt = "$prompt\! "
  endif
endif

set mail=/usr/spool/mail/$logname
set history = 18

set SYSOP = "ind"

# Setup the aliases
alias gt	'set gt=`/bin/pwd`;cd \!^'
alias gb	'set gb=`/bin/pwd`;cd $gt;set gt=$gb'
alias H		history
alias ind	'more /z/indkonst'
alias cm 'crypt `getkey` <\!* >.$$;m .$$;crypt `getkey` <.$$ >\!*;echo >.$$;/bin/rm .$$'
alias ccat 'crypt `getkey` <\!*'
alias clp	xq -q lpr:1 -s
alias agrep	'grep "`agrp \!^`" \!$'
alias dir	'ls -lAF'
alias jx	'set term=jx ; setenv TERM jx'
alias ju	'set term=ju ; setenv TERM ju'
alias h19	'set term=h19 ; setenv TERM h19'
alias ls	'ls -F'
alias ux	'/z/unitex/unitex'
alias unitex	'/z/unitex/unitex'
alias us	'/z/unitex/ut_que \!*'
alias uq	'/z/unitex/ut_qh'
alias uman	'more /usr/man/manU/\!*.U'
alias addnews	'csh /z/c/addnews'
alias addtel	'set miparam=/z/telefonlista;source /z/bin/edt'
alias rm	'touch \!*;mv \!* /z/tmp/rmfiles'
alias m		'set miparam="\!*";source /z/bin/edt'

# s{tt lpr:n med svenska tecken
alias swe 'echo -n "\0233M" | lpr'

# s{tt lpr:n med engelska tecken
alias eng 'echo -n "\0233K" | lpr'

#

if ($?firsttime != 0) then
  /usr/games/fortune
  set firsttime = "notfirst"
endif

sync
