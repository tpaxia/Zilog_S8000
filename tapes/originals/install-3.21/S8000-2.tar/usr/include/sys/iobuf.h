/* @[$]iobuf.h	4.2  06/11/84 12:30:59 - Zilog Inc */

/*
 * Each block device has a iobuf, which contains private state stuff and 2 list
 * heads: the b_forw/b_back list, which is doubly linked and has all the buffers
 * currently associated with that major device; and the d_actf/d_actl list, 
 * which is private to the device but in fact is always used for the head and 
 * tail of the I/O queue for the device. Various routines in bio.c look at 
 * b_forw/b_back (notice they are the same as in the buf structure) but the rest
 * is private to each device driver.
 */

struct iobuf
{
	/*
	 * The first five entries in this structure parallel the buf
	 * structure and must remain in place in order to occupy the
	 * same positions taken by b_flags through av_back.
	 */
	int		b_flags;	/* see buf.h 			      */
	struct buf 	*b_forw;	/* first buffer for this dev 	      */
	struct buf 	*b_back;	/* last buffer for this dev 	      */
	struct buf 	*b_actf;	/* head of I/O queue 		      */
	struct buf 	*b_actl;	/* tail of I/O queue 		      */

	dev_t		b_dev;		/* major+minor device name 	      */
	char		b_active;	/* busy flag 			      */
	char		b_errcnt;	/* error count (for recovery) 	      */
	struct eblock	*io_erec;	/* error record 		      */
	int		io_nreg;	/* num of bytes of dev's err status   */
	char		*io_addr;	/* where to find the dev's err status */
	struct iostat	*io_stp;	/* unit I/O statistics 		      */
	int		io_s1;		/* space for drivers to leave things  */
	int		io_s2;		/* space for drivers to leave things  */
};

# define tabinit(dv,stat)	{0,0,0,0,0,makedev(dv,0),0,0,0,0,0,stat,0,0}

# define B_ONCE		01	/* flag for once only driver operations */
# define B_TAPE		02	/* this is a magtape (no bdwrite) 	*/
# define B_TIME		04	/* for timeout use 			*/
